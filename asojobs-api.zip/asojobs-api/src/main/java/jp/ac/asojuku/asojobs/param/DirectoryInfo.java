package jp.ac.asojuku.asojobs.param;

public class DirectoryInfo {
	public static String SecurityInfoFile = "/root/t.csv";
}
