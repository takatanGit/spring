package jp.ac.asojuku.asojobs.dao;

public interface BooksDAO {
	
}
