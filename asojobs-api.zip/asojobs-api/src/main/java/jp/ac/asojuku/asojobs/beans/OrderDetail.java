package jp.ac.asojuku.asojobs.beans;

public class OrderDetail {
	
	private String productid;
	private String productname;
	
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	

}
