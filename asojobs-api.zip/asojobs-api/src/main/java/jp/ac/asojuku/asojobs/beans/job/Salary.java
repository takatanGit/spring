package jp.ac.asojuku.asojobs.beans.job;

public class Salary {
	public Salary(){}
	private Integer one_salary;
	private Integer two_salary;
	private Integer three_salary;
	private Integer four_salary;
	private Integer bonus_freq;
	private Integer bonus_month;
	private Integer pay_raise;
	private Integer minimum;
	private Integer maximum;
	private Integer pay_raise_index;
	private String trans_exp_salary;
	public Integer getOne_salary() {
		return one_salary;
	}
	public void setOne_salary(Integer one_salary) {
		this.one_salary = one_salary;
	}
	public Integer getTwo_salary() {
		return two_salary;
	}
	public void setTwo_salary(Integer two_salary) {
		this.two_salary = two_salary;
	}
	public Integer getThree_salary() {
		return three_salary;
	}
	public void setThree_salary(Integer three_salary) {
		this.three_salary = three_salary;
	}
	public Integer getFour_salary() {
		return four_salary;
	}
	public void setFour_salary(Integer four_salary) {
		this.four_salary = four_salary;
	}
	public Integer getBonus_freq() {
		return bonus_freq;
	}
	public void setBonus_freq(Integer bonus_freq) {
		this.bonus_freq = bonus_freq;
	}
	public Integer getBonus_month() {
		return bonus_month;
	}
	public void setBonus_month(Integer bonus_month) {
		this.bonus_month = bonus_month;
	}
	public Integer getPay_raise() {
		return pay_raise;
	}
	public void setPay_raise(Integer pay_raise) {
		this.pay_raise = pay_raise;
	}
	public Integer getMinimum() {
		return minimum;
	}
	public void setMinimum(Integer minimum) {
		this.minimum = minimum;
	}
	public Integer getMaximum() {
		return maximum;
	}
	public void setMaximum(Integer maximum) {
		this.maximum = maximum;
	}
	public Integer getPay_raise_index() {
		return pay_raise_index;
	}
	public void setPay_raise_index(Integer pay_raise_index) {
		this.pay_raise_index = pay_raise_index;
	}
	public String getTrans_exp_salary() {
		return trans_exp_salary;
	}
	public void setTrans_exp_salary(String trans_exp_salary) {
		this.trans_exp_salary = trans_exp_salary;
	}
}
