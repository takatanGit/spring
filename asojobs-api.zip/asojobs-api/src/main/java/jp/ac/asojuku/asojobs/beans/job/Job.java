package jp.ac.asojuku.asojobs.beans.job;

public class Job {
	public Job(){}
	private String job_name;

	public String getJob_name() {
		return job_name;
	}

	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}
}
