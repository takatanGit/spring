package jp.ac.asojuku.asojobs.beans;

public class ManagerAccountExistsRespncse {
	private  int code;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
}
