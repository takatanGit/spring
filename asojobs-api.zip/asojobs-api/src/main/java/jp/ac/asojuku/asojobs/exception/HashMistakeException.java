package jp.ac.asojuku.asojobs.exception;

public class HashMistakeException extends Exception{
	public HashMistakeException(String err){
		super(err);
	}
}
