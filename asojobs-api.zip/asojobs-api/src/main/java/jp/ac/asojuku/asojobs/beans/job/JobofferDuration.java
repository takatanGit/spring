package jp.ac.asojuku.asojobs.beans.job;

public class JobofferDuration {
	public JobofferDuration(){}
	private String joboffer_start;
	private String joboffer_end;
	private Integer joboffer_visit;
	private Integer joboffer_des_school;
	private String joboffer_des_day;
	private String joboffer_des_day_oh;
	private String joboffer_des_loc;
	private String com_explan_day;
	private String com_explan_place;
	private String trans_exp;
	private String com_explan_day_oh;
	private String submit_document;
	private String submit_document_etc;
	private String selection_method;
	private String selection_method_etc;
	private String baggage;
	private String baggage_etc;
	private String joboffer_decide_day;
	private Integer joboffer_decide_during;
	private Integer receptionist_method;
	private String receptionistm_ethod_navigation;
	private String start_work_day;
	private String select_day;
	private String select_place;
	public String getSelect_place() {
		return select_place;
	}
	public void setSelect_place(String select_place) {
		this.select_place = select_place;
	}
	public String getJoboffer_start() {
		return joboffer_start;
	}
	public void setJoboffer_start(String joboffer_start) {
		this.joboffer_start = joboffer_start;
	}
	public String getJoboffer_end() {
		return joboffer_end;
	}
	public void setJoboffer_end(String joboffer_end) {
		this.joboffer_end = joboffer_end;
	}
	public Integer getJoboffer_visit() {
		return joboffer_visit;
	}
	public void setJoboffer_visit(Integer joboffer_visit) {
		this.joboffer_visit = joboffer_visit;
	}
	public Integer getJoboffer_des_school() {
		return joboffer_des_school;
	}
	public void setJoboffer_des_school(Integer joboffer_des_school) {
		this.joboffer_des_school = joboffer_des_school;
	}
	public String getJoboffer_des_day() {
		return joboffer_des_day;
	}
	public void setJoboffer_des_day(String joboffer_des_day) {
		this.joboffer_des_day = joboffer_des_day;
	}
	public String getJoboffer_des_day_oh() {
		return joboffer_des_day_oh;
	}
	public void setJoboffer_des_day_oh(String joboffer_des_day_oh) {
		this.joboffer_des_day_oh = joboffer_des_day_oh;
	}
	public String getJoboffer_des_loc() {
		return joboffer_des_loc;
	}
	public void setJoboffer_des_loc(String joboffer_des_loc) {
		this.joboffer_des_loc = joboffer_des_loc;
	}
	public String getCom_explan_day() {
		return com_explan_day;
	}
	public void setCom_explan_day(String com_explan_day) {
		this.com_explan_day = com_explan_day;
	}
	public String getCom_explan_place() {
		return com_explan_place;
	}
	public void setCom_explan_place(String com_explan_place) {
		this.com_explan_place = com_explan_place;
	}
	public String getTrans_exp() {
		return trans_exp;
	}
	public void setTrans_exp(String trans_exp) {
		this.trans_exp = trans_exp;
	}
	public String getCom_explan_day_oh() {
		return com_explan_day_oh;
	}
	public void setCom_explan_day_oh(String com_explan_day_oh) {
		this.com_explan_day_oh = com_explan_day_oh;
	}
	public String getSubmit_document() {
		return submit_document;
	}
	public void setSubmit_document(String submit_document) {
		this.submit_document = submit_document;
	}
	public String getSubmit_document_etc() {
		return submit_document_etc;
	}
	public void setSubmit_document_etc(String submit_document_etc) {
		this.submit_document_etc = submit_document_etc;
	}
	public String getSelection_method() {
		return selection_method;
	}
	public void setSelection_method(String selection_method) {
		this.selection_method = selection_method;
	}
	public String getSelection_method_etc() {
		return selection_method_etc;
	}
	public void setSelection_method_etc(String selection_method_etc) {
		this.selection_method_etc = selection_method_etc;
	}
	public String getBaggage() {
		return baggage;
	}
	public void setBaggage(String baggage) {
		this.baggage = baggage;
	}
	public String getBaggage_etc() {
		return baggage_etc;
	}
	public void setBaggage_etc(String baggage_etc) {
		this.baggage_etc = baggage_etc;
	}
	public String getJoboffer_decide_day() {
		return joboffer_decide_day;
	}
	public void setJoboffer_decide_day(String joboffer_decide_day) {
		this.joboffer_decide_day = joboffer_decide_day;
	}
	public Integer getJoboffer_decide_during() {
		return joboffer_decide_during;
	}
	public void setJoboffer_decide_during(Integer joboffer_decide_during) {
		this.joboffer_decide_during = joboffer_decide_during;
	}
	public Integer getReceptionist_method() {
		return receptionist_method;
	}
	public void setReceptionist_method(Integer receptionist_method) {
		this.receptionist_method = receptionist_method;
	}
	public String getReceptionistm_ethod_navigation() {
		return receptionistm_ethod_navigation;
	}
	public void setReceptionistm_ethod_navigation(String receptionistm_ethod_navigation) {
		this.receptionistm_ethod_navigation = receptionistm_ethod_navigation;
	}
	public String getStart_work_day() {
		return start_work_day;
	}
	public void setStart_work_day(String start_work_day) {
		this.start_work_day = start_work_day;
	}
	public String getSelect_day() {
		return select_day;
	}
	public void setSelect_day(String select_day) {
		this.select_day = select_day;
	}
}
