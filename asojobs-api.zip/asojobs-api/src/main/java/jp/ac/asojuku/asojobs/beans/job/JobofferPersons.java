package jp.ac.asojuku.asojobs.beans.job;

public class JobofferPersons {
	public JobofferPersons(){}
	private Integer joboffer_unisex;
	private Integer joboffer_man;
	private Integer joboffer_woman;
	public Integer getJoboffer_unisex() {
		return joboffer_unisex;
	}
	public void setJoboffer_unisex(Integer joboffer_unisex) {
		this.joboffer_unisex = joboffer_unisex;
	}
	public Integer getJoboffer_man() {
		return joboffer_man;
	}
	public void setJoboffer_man(Integer joboffer_man) {
		this.joboffer_man = joboffer_man;
	}
	public Integer getJoboffer_woman() {
		return joboffer_woman;
	}
	public void setJoboffer_woman(Integer joboffer_woman) {
		this.joboffer_woman = joboffer_woman;
	}
}
