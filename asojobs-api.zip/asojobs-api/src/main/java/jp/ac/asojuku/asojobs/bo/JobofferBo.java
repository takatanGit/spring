package jp.ac.asojuku.asojobs.bo;

import jp.ac.asojuku.asojobs.beans.JobofferRegistrationInfo;

public interface JobofferBo {
	public Object entryJoboffer(JobofferRegistrationInfo beans);
}
